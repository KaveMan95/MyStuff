package net.runelite.client.plugins.theatre;

public enum TheatreRoom
{
	MAIDEN,
	BLOAT,
	NYLOCAS,
	SOTETSEG,
	XARPUS,
	VERSIK,
	UNKNOWN
}