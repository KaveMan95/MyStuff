package net.runelite.client.plugins.theatre.timers;

import java.util.Map;

public interface Timeable
{
	Map<String, Long> getTimes();
}